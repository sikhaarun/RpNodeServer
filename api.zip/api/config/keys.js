module.exports=    {
        mongoURI:"mongodb://localhost/devconnect",
        keyorSecret:"secret"
    }